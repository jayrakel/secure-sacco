package com.jaytechwave.sacco.modules.reports.api.controller;

import com.jaytechwave.sacco.modules.reports.api.dto.ReportDTOs.FinancialOverviewDTO;
import com.jaytechwave.sacco.modules.reports.api.dto.ReportDTOs.StatementItemDTO;
import com.jaytechwave.sacco.modules.reports.api.dto.ReportDTOs.MemberMiniSummaryDTO;
import com.jaytechwave.sacco.modules.reports.api.dto.ReportDTOs.LoanArrearsDTO;
import com.jaytechwave.sacco.modules.reports.api.dto.ReportDTOs.PaymentLineDTO;
import com.jaytechwave.sacco.modules.reports.domain.service.ReportService;
import com.jaytechwave.sacco.modules.users.domain.entity.User;
import com.jaytechwave.sacco.modules.users.domain.repository.UserRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
@Tag(name = "Reports", description = "Financial reports, member statements, arrears and collection summaries")
public class ReportController {

    private final ReportService reportService;
    private final UserRepository userRepository;

    @Operation(summary = "Financial overview", description = "Returns financial summary for all members. Requires REPORTS_READ.")
    @GetMapping("/financial-overview")
    @PreAuthorize("hasAuthority('REPORTS_READ')")
    public ResponseEntity<List<FinancialOverviewDTO>> getFinancialOverview() {
        return ResponseEntity.ok(reportService.getMemberFinancialOverview());
    }

    // --- NEW: MINI SUMMARY WIDGET ENDPOINT ---
    @Operation(summary = "My financial summary", description = "Returns a mini summary widget for the authenticated member.")
    @GetMapping("/me/summary")
    @PreAuthorize("hasAuthority('ROLE_MEMBER')")
    public ResponseEntity<MemberMiniSummaryDTO> getMySummary() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new AccessDeniedException("User session not found"));

        if (user.getMember() == null) {
            return ResponseEntity.ok(new MemberMiniSummaryDTO());
        }

        return ResponseEntity.ok(reportService.getMySummary(user.getMember().getId()));
    }

    @Operation(summary = "Member transaction statement", description = "Returns a member's statement. Staff (REPORTS_READ) can view any member; members can only view their own.")
    @GetMapping("/members/{memberId}/statement")
    public ResponseEntity<com.jaytechwave.sacco.modules.reports.api.dto.ReportDTOs.StatementResponseDTO> getMemberStatement(
            @PathVariable UUID memberId,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        boolean hasReportsRead = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("REPORTS_READ"));

        // RBAC Enforcement: Staff can read any, Member can only read their own!
        if (!hasReportsRead) {
            User user = userRepository.findByEmail(auth.getName())
                    .orElseThrow(() -> new AccessDeniedException("User session not found"));
            if (user.getMember() == null || !user.getMember().getId().equals(memberId)) {
                throw new AccessDeniedException("Security Violation: You do not have permission to view another member's statement.");
            }
        }

        return ResponseEntity.ok(reportService.getMemberStatementWithSummary(memberId, from, to));
    }

    // --- NEW: LOAN ARREARS AGING REPORT ---
    @Operation(summary = "Loan arrears aging report", description = "Returns loans in arrears grouped by aging bucket. Requires REPORTS_READ.")
    @GetMapping("/loans/arrears")
    @PreAuthorize("hasAuthority('REPORTS_READ')")
    public ResponseEntity<List<LoanArrearsDTO>> getLoanArrearsReport(
            @RequestParam(required = false) String bucket) {
        return ResponseEntity.ok(reportService.getLoanArrearsReport(bucket));
    }

    @Operation(summary = "Daily collections summary", description = "Returns total collections for a given date. Requires REPORTS_READ.")
    @GetMapping("/collections/daily")
    @PreAuthorize("hasAuthority('REPORTS_READ')")
    public ResponseEntity<com.jaytechwave.sacco.modules.reports.api.dto.ReportDTOs.DailyCollectionDTO> getDailyCollections(
            @RequestParam(required = false) String date) {
        return ResponseEntity.ok(reportService.getDailyCollections(date));
    }

    // --- DRILLDOWN: Individual rows for the Daily Collections page ---
    @Operation(summary = "Daily collections line items", description = "Returns individual payment rows for a given date. Requires REPORTS_READ.")
    @GetMapping("/collections/daily/lines")
    @PreAuthorize("hasAuthority('REPORTS_READ')")
    public ResponseEntity<List<PaymentLineDTO>> getDailyCollectionLines(
            @RequestParam(required = false) String date) {
        return ResponseEntity.ok(reportService.getDailyCollectionLines(date));
    }

    @Operation(summary = "Income report", description = "Returns interest and fee income for a date range. Requires REPORTS_READ.")
    @GetMapping("/income")
    @PreAuthorize("hasAuthority('REPORTS_READ')")
    public ResponseEntity<com.jaytechwave.sacco.modules.reports.api.dto.ReportDTOs.IncomeReportDTO> getIncomeReport(
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to) {
        return ResponseEntity.ok(reportService.getIncomeReport(from, to));
    }
}